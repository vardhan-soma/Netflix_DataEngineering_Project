# Databricks notebook source
# MAGIC %md
# MAGIC ### Incremental Data Loading

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE SCHEMA IF NOT EXISTS netflix_catalog.netflix_schema

# COMMAND ----------

checkpoint_location = 'abfss://silver@netflixstoragesree.dfs.core.windows.net/checkPoint'

# COMMAND ----------

dbutils.fs.ls('abfss://raw@netflixstoragesree.dfs.core.windows.net/Netflix_Titles/')

# COMMAND ----------

files = dbutils.fs.ls('abfss://raw@netflixstoragesree.dfs.core.windows.net/Netflix_Titles/')
display(files)

# COMMAND ----------

df = spark.read.format("csv")\
    .option("header", "true")\
        .load('abfss://raw@netflixstoragesree.dfs.core.windows.net/Netflix_Titles/netflix_titles.csv')
df.display()

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW CATALOGS;

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW SCHEMAS IN netflix_catalog;

# COMMAND ----------

files = dbutils.fs.ls("abfss://raw@netflixstoragesree.dfs.core.windows.net/Netflix_Titles/")
display(files)


# COMMAND ----------

df = spark.read.format("csv") \
    .option("header", "true") \
    .load("abfss://raw@netflixstoragesree.dfs.core.windows.net/Netflix_Titles/netflix_titles.csv")

df.show(5)


# COMMAND ----------

dbutils.fs.put("abfss://raw@netflixstoragesree.dfs.core.windows.net/Netflix_Titles/test.txt", "This is a test file")


# COMMAND ----------

df = spark.readStream\
  .format("cloudFiles")\
  .option("cloudFiles.format", "csv")\
  .option("cloudFiles.schemaLocation", checkpoint_location)\
  .load('abfss://raw@netflixstoragesree.dfs.core.windows.net')

# COMMAND ----------

display(df)

# COMMAND ----------

df.writeStream\
  .option("checkpointLocation", checkpoint_location)\
  .trigger(processingTime="10 seconds")\
  .start("abfss://bronze@netflixstoragesree.dfs.core.windows.net/Netflix_titles")