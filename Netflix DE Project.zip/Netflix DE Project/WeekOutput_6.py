# Databricks notebook source
var = dbutils.jobs.taskValues.get(taskKey='Weekday_LookUp', key='weekOutput')

# COMMAND ----------

print(var)