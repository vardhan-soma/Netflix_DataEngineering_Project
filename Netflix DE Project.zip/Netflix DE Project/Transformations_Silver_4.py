# Databricks notebook source
# MAGIC %md
# MAGIC #### Data Transformations

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

df_titles = spark.read.format('delta')\
                  .option('header', 'true')\
                  .option('inferSchema', 'true')\
                  .load('abfss://bronze@netflixstoragesree.dfs.core.windows.net/Netflix_titles')

# COMMAND ----------

df_titles.display()

# COMMAND ----------

df_titles = df_titles.fillna({'duration_minutes' : 0, 'duration_seasons' : 1})
df_titles.display()

# COMMAND ----------

df_titles = df_titles.withColumn('duration_minutes', col('duration_minutes').cast(IntegerType()))\
                     .withColumn('duration_seasons', col('duration_seasons').cast(IntegerType()))
df_titles.printSchema()

# COMMAND ----------

df_titles.display()

# COMMAND ----------

df_titles = df_titles.withColumn('shortTitle', split(col('title'),':')[0])\
                     .withColumn('rating', split('rating', '-')[0])
df_titles.display()

# COMMAND ----------

df_titles = df_titles.withColumn('type_flag', when(col('type')=='Movie', 1)\
                                        .when(col('type')=='TV Show', 2)\
                                        .otherwise(0))
df_titles.display()

# COMMAND ----------

from pyspark.sql.window import Window

# COMMAND ----------

df_titles = df_titles.withColumn('duration_ranking', dense_rank().over(Window.orderBy(col('duration_minutes').desc())))
df_titles.display()

# COMMAND ----------

df_titles.createOrReplaceTempView("temp_view")

# COMMAND ----------

df_titles.createOrReplaceGlobalTempView("global_temp_view") ##will be closed once the session is done

# COMMAND ----------

df_titles = spark.sql(
    """
    SELECT * FROM temp_view
    """
)

# COMMAND ----------

df_titles = spark.sql(
    """
    SELECT * FROM global_temp.global_temp_view
    """
)

# COMMAND ----------

df_titles.groupBy('type').agg(count('*').alias('total_count')).display()


# COMMAND ----------

df_titles.display()

# COMMAND ----------

df_titles.write.format('delta')\
        .mode('overwrite')\
        .option('path', 'abfss://silver@netflixstoragesree.dfs.core.windows.net/netflix_titles')\
        .save()